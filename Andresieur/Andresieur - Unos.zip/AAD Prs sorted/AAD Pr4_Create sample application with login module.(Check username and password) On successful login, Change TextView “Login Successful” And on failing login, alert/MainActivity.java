package com.example.aad_pr4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView txtheadline;
    EditText edteemail1, edtpw1;
    Button btnlog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        txtheadline = findViewById(R.id.txthead);
        edteemail1 = findViewById(R.id.edt_email1);
        edtpw1 = findViewById(R.id.edt_passwd1);
        btnlog = findViewById(R.id.btnLog);

        // Set click listener
        btnlog.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Check login credentials
        if ((edteemail1.getText().toString().equals("user@gmail.com")) &&
                (edtpw1.getText().toString().equals("1234"))) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }
}
