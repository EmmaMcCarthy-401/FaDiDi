package com.example.aad_pr6;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText edittextUN;
    private EditText edittextPass;
    private Button btnLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittextUN = findViewById(R.id.edittxt_Username);
        edittextPass = findViewById(R.id.edittxt_Password);
        btnLog = findViewById(R.id.button_Login);
        edittextUN.addTextChangedListener(loginTextWatcher);
        edittextPass.addTextChangedListener(loginTextWatcher);
    }

    private final TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String usernameInput = edittextUN.getText().toString();
            String passwordInput = edittextPass.getText().toString();
            btnLog.setEnabled(!usernameInput.isEmpty() && !passwordInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}