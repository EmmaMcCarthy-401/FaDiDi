package com.example.aad_pr7;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private EditText num1EditText, num2EditText;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1EditText = findViewById(R.id.num1EditText);
        num2EditText = findViewById(R.id.num2EditText);
        resultTextView = findViewById(R.id.resultTextView);
        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(v -> performCalculation('+'));
        Button subtractButton = findViewById(R.id.subtractButton);
        subtractButton.setOnClickListener(v -> performCalculation('-'));
        Button multiplyButton = findViewById(R.id.multiplyButton);
        multiplyButton.setOnClickListener(v -> performCalculation('*'));
        Button divideButton = findViewById(R.id.divideButton);
        divideButton.setOnClickListener(v -> performCalculation('/'));
        Button sqrtButton = findViewById(R.id.sqrtButton);
        sqrtButton.setOnClickListener(v -> calculateSquareRoot());
    }

    @SuppressLint("SetTextI18n")
    private void performCalculation(char operator) {
        String num1Str = num1EditText.getText().toString();
        String num2Str = num2EditText.getText().toString();
        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);
        double result = 0;
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                break;
        }
        DecimalFormat df = new DecimalFormat("#.##");
        resultTextView.setText("Result: " + df.format(result));
    }

    @SuppressLint("SetTextI18n")
    private void calculateSquareRoot() {
        String num1Str = num1EditText.getText().toString();
        if (num1Str.isEmpty()) {
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }
        double num = Double.parseDouble(num1Str);
        double sqrtResult = Math.sqrt(num);
        DecimalFormat df = new DecimalFormat("#.##");
        resultTextView.setText("Square Root: " + df.format(sqrtResult));
    }
}