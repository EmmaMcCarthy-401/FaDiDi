const express = require("express");
const app = express();
const port = 3000;
const students = [
  { id: 1, name: "John", age: 20, course: "Mathematics" },
  { id: 2, name: "Jane", age: 22, course: "Physics" },
  { id: 3, name: "Sam ", age: 19, course: "Computer Science" },
];

app.get("/", (req, res) => {
  let studentList = "<h1>Student Information</h1><ul>";
  students.forEach((student) => {
    studentList += `<li>${student.name}, ${student.age} years old, studying ${student.course}</li>`;
  });
  studentList += "</ul>";
  res.send(studentList);
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
