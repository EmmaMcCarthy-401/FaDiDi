const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.get("/", (req, res) => {
  res.send(`
    <form action="/login" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <button type="submit">Login</button>
    </form>
`);
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  
  if (username === "admin" && password === "password") {
    res.send(`<h1>Welcome, ${username}!</h1>`);
  } else {
    res.send("<h1>Invalid credentials. Please try again.</h1>");
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
